package Utils;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Random;

public class Authentication {
    public static String hashMD5(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] messageDigest = md.digest(input.getBytes());
            BigInteger no = new BigInteger(1, messageDigest);

            // Convert message digest into hex value
            String hashtext = no.toString(16);
            while (hashtext.length() < 32) {
                hashtext = "0" + hashtext;
            }
            return hashtext;
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("MD5 algorithm not available", e);
        }
    }

    public static String generateCaptcha() {
        // Generate a random CAPTCHA
        Random random = new Random();
        int captchaLength = 8;
        StringBuilder captcha = new StringBuilder();
        for (int i = 0; i < captchaLength; i++) {
            char randomChar = (char) (random.nextInt(26) + 'a');
            captcha.append(randomChar);
        }
        return captcha.toString();
    }
}
