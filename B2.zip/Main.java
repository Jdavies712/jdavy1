import User.Register;
import User.UserAuthentication;
import Utils.Authentication;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Hello and welcome!");
        System.out.println("To start using DBMS");
        System.out.println("1. Register As New user");
        System.out.println("2. Login");
        System.out.println("Please enter your choice:");
        int choice = sc.nextInt();
        sc.nextLine();
        System.out.print("Please enter your username: ");
        String username = sc.nextLine();
        System.out.print("Enter your password: ");
        String password = sc.nextLine();
        switch(choice) {
            case 1:
                Register user = new Register();
                user.registerUser(username, password);
                break;
            case 2: String captcha = Authentication.generateCaptcha();
                  System.out.println("CAPTCHA: " + captcha);

                System.out.print("Enter the CAPTCHA: ");
                String userCaptcha = sc.nextLine();

                if (!captcha.equalsIgnoreCase(userCaptcha)) {
                    System.out.println("Invalid Captcha. Please try again.");

                }else{
                    UserAuthentication a = new UserAuthentication();
                    a.authenticateUser(username, password);
                }
                break;
            default: System.out.println("Invalid Option");
        }
    }
}
