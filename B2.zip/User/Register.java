package User;
import Utils.Authentication;

import java.io.*;

public class Register {
    private static int userId = 1;
    public static void registerUser(String username, String password) {
        // Hashing the password using MD5
        String hashedPassword = Authentication.hashMD5(password);

        // Creating User instance
        User user = new User(userId, username, hashedPassword);

        try (PrintWriter writer = new PrintWriter(new FileWriter("files/Users.txt", true))) {
            // Add user details to the Users.txt file
            writer.println(user.getId() + "," + user.getUsername() + "," + user.getPassword());
            System.out.println("User registered successfully!");
        } catch (IOException e) {
            System.out.println("Error while registering user: " + e.getMessage());
        }
    }
}
