package User;

import Utils.Authentication;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class UserAuthentication {
    public static boolean authenticateUser(String username, String enteredPassword) {
        // Read Users.txt file to check for username and password
        try (Scanner scanner = new Scanner(new File("files/Users.txt"))) {
            while (scanner.hasNextLine()) {
                String[] userDetails = scanner.nextLine().split(",");
                if (userDetails[1].equalsIgnoreCase(username) &&
                        userDetails[2].equals(Authentication.hashMD5(enteredPassword))) {
                    System.out.println("User authenticated successfully!");
                    return true;
                } else{
                    System.out.println("Invalid Password!");
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("Users.txt file not found");
        }
        System.out.println("Authentication failed!");
        return false;
    }
}
